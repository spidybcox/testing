import express from 'express';
import nodemailer from 'nodemailer';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { EMAIL_CONFIG, fetchEmails, getFolders, searchEmails } from './services/email.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const port = 3000;

app.use(express.json());
app.use(express.static('public'));

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: EMAIL_CONFIG.user,
    pass: EMAIL_CONFIG.password
  }
});

app.post('/api/send-email', async (req, res) => {
  const { to, subject, text } = req.body;
  try {
    await transporter.sendMail({
      from: EMAIL_CONFIG.user,
      to,
      subject,
      text
    });
    res.json({ success: true, message: 'Email sent successfully' });
  } catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ success: false, message: 'Error sending email' });
  }
});

app.get('/api/read-emails', async (req, res) => {
  const { folder } = req.query;
  try {
    const emails = await fetchEmails(folder);
    res.json({ success: true, emails });
  } catch (error) {
    console.error('Error reading emails:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error reading emails: ' + error.message 
    });
  }
});

app.get('/api/folders', async (req, res) => {
  try {
    const folders = await getFolders();
    res.json({ success: true, folders });
  } catch (error) {
    console.error('Error fetching folders:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching folders: ' + error.message 
    });
  }
});

app.get('/api/search', async (req, res) => {
  const { query } = req.query;
  try {
    const results = await searchEmails(query);
    res.json({ success: true, emails: results });
  } catch (error) {
    console.error('Error searching emails:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error searching emails: ' + error.message 
    });
  }
});

app.get('/', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});