export const emailTemplates = {
  meeting: {
    subject: "Meeting Invitation",
    text: "I would like to schedule a meeting with you. Please let me know your availability."
  },
  thanks: {
    subject: "Thank You",
    text: "Thank you for your time and assistance."
  },
  followup: {
    subject: "Follow-up",
    text: "I am following up on our previous conversation."
  },
  urgent: {
    subject: "Urgent Matter",
    text: "This requires your immediate attention."
  }
};