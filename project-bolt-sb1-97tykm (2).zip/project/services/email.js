import Imap from 'imap';
import { simpleParser } from 'mailparser';

export const EMAIL_CONFIG = {
  user: 'cm9020100@gmail.com',
  password: 'kugd pxkt rvxk qxhv',
  contacts: {
    john: 'john@example.com',
    jane: '',
    user: 'sangeerth829@gmail.com'
  }
};

export function createImapConnection() {
  return new Imap({
    user: EMAIL_CONFIG.user,
    password: EMAIL_CONFIG.password,
    host: 'imap.gmail.com',
    port: 993,
    tls: true,
    tlsOptions: { rejectUnauthorized: false },
    authTimeout: 3000
  });
}

export async function fetchEmails(folder = 'INBOX', searchCriteria = ['ALL']) {
  return new Promise((resolve, reject) => {
    const imap = createImapConnection();
    const emails = [];

    imap.once('ready', () => {
      imap.openBox(folder, false, (err, box) => {
        if (err) {
          imap.end();
          return reject(err);
        }

        const total = box.messages.total;
        const start = Math.max(total - 9, 1);
        const fetch = imap.seq.fetch(`${start}:*`, {
          bodies: ['HEADER.FIELDS (FROM SUBJECT)', 'TEXT'],
          struct: true
        });

        fetch.on('message', (msg) => {
          const email = {};
          
          msg.on('body', (stream, info) => {
            let buffer = '';
            stream.on('data', (chunk) => {
              buffer += chunk.toString('utf8');
            });
            stream.once('end', () => {
              if (info.which === 'TEXT') {
                email.content = buffer;
              } else {
                const header = Imap.parseHeader(buffer);
                email.from = header.from?.[0] || 'Unknown';
                email.subject = header.subject?.[0] || 'No Subject';
              }
            });
          });

          msg.once('end', () => {
            if (email.from && email.subject) {
              emails.push(email);
            }
          });
        });

        fetch.once('error', (err) => {
          imap.end();
          reject(err);
        });

        fetch.once('end', () => {
          imap.end();
          resolve(emails.reverse());
        });
      });
    });

    imap.once('error', (err) => {
      reject(err);
    });

    imap.connect();
  });
}

export async function getFolders() {
  return new Promise((resolve, reject) => {
    const imap = createImapConnection();

    imap.once('ready', () => {
      imap.getBoxes((err, boxes) => {
        imap.end();
        if (err) reject(err);
        else resolve(Object.keys(boxes));
      });
    });

    imap.once('error', (err) => {
      reject(err);
    });

    imap.connect();
  });
}

export async function searchEmails(query) {
  const emails = await fetchEmails();
  const searchResults = emails.filter(email => 
    email.subject.toLowerCase().includes(query.toLowerCase()) ||
    email.from.toLowerCase().includes(query.toLowerCase()) ||
    email.content.toLowerCase().includes(query.toLowerCase())
  );
  return searchResults;
}