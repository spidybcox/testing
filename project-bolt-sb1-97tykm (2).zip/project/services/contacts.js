export const contacts = {
  async add(name, email) {
    const contacts = await this.getAll();
    contacts[name.toLowerCase()] = email;
    localStorage.setItem('contacts', JSON.stringify(contacts));
  },

  async remove(name) {
    const contacts = await this.getAll();
    delete contacts[name.toLowerCase()];
    localStorage.setItem('contacts', JSON.stringify(contacts));
  },

  async getAll() {
    const stored = localStorage.getItem('contacts');
    return stored ? JSON.parse(stored) : {};
  },

  async get(name) {
    const contacts = await this.getAll();
    return contacts[name.toLowerCase()];
  }
};