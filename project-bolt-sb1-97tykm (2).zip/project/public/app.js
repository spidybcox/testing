// Import sound utilities
const sounds = {
    success: new Howl({
        src: ['/sounds/success.mp3'],
        volume: 0.5
    }),
    error: new Howl({
        src: ['/sounds/error.mp3'],
        volume: 0.5
    }),
    notification: new Howl({
        src: ['/sounds/notification.mp3'],
        volume: 0.3
    })
};

// Email templates
const emailTemplates = {
    meeting: {
        subject: "Meeting Invitation",
        text: "I would like to schedule a meeting with you. Please let me know your availability."
    },
    thanks: {
        subject: "Thank You",
        text: "Thank you for your time and assistance."
    },
    followup: {
        subject: "Follow-up",
        text: "I am following up on our previous conversation."
    },
    urgent: {
        subject: "Urgent Matter",
        text: "This requires your immediate attention."
    }
};

// Contact management
const contacts = {
    async add(name, email) {
        const contacts = await this.getAll();
        contacts[name.toLowerCase()] = email;
        localStorage.setItem('contacts', JSON.stringify(contacts));
    },

    async remove(name) {
        const contacts = await this.getAll();
        delete contacts[name.toLowerCase()];
        localStorage.setItem('contacts', JSON.stringify(contacts));
    },

    async getAll() {
        const stored = localStorage.getItem('contacts');
        return stored ? JSON.parse(stored) : {};
    },

    async get(name) {
        const contacts = await this.getAll();
        return contacts[name.toLowerCase()];
    }
};

class VoiceEmailSystem {
    constructor() {
        this.synthesis = window.speechSynthesis;
        this.recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        this.setupRecognition();
        this.setupUI();
        this.currentState = 'idle';
        this.emailData = {};
        this.hasStarted = false;
        this.speechRate = 1;
        this.currentFolder = 'INBOX';
        this.shortcuts = new Map([
            ['inbox', () => this.changeFolder('INBOX')],
            ['sent', () => this.changeFolder('SENT')],
            ['draft', () => this.changeFolder('DRAFT')],
            ['trash', () => this.changeFolder('TRASH')],
            ['urgent', () => this.useTemplate('urgent')],
            ['meeting', () => this.useTemplate('meeting')],
            ['thanks', () => this.useTemplate('thanks')],
            ['follow up', () => this.useTemplate('followup')]
        ]);
    }

    setupRecognition() {
        this.recognition.continuous = false;
        this.recognition.interimResults = false;
        this.recognition.lang = 'en-US';

        this.recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript.toLowerCase();
            this.handleCommand(transcript);
        };

        this.recognition.onend = () => {
            if (this.currentState !== 'idle') {
                this.recognition.start();
            }
        };

        this.recognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            this.updateStatus(`Error: ${event.error}`);
            sounds.error.play();
        };
    }

    setupUI() {
        this.statusDiv = document.getElementById('status');
        this.transcriptDiv = document.getElementById('transcript');

        document.addEventListener('click', () => {
            if (!this.hasStarted) {
                this.start();
            }
        });

        document.addEventListener('keydown', (e) => {
            if (e.code === 'Space') {
                this.toggleSpeech();
            } else if (e.code === 'KeyH') {
                this.speakHelp();
            }
        });
    }

    async speakHelp() {
        const helpText = `
            Available commands:
            - Compose: Start composing a new email
            - Read: Read emails from current folder
            - Search: Search through emails
            - Folders: List and switch folders
            - Contacts: Manage contacts
            - Templates: Use email templates
            - Speed up or Slow down: Adjust speech rate
            - Help: List all commands
            - Exit: Exit the system
            
            Shortcuts:
            - Space: Pause/Resume speech
            - H: Help menu
        `;
        await this.speak(helpText);
    }

    updateStatus(text) {
        this.statusDiv.textContent = text;
    }

    speak(text) {
        return new Promise(resolve => {
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.rate = this.speechRate;
            utterance.onend = resolve;
            utterance.onerror = (event) => {
                console.error('Speech synthesis error:', event);
                sounds.error.play();
                resolve();
            };
            this.synthesis.speak(utterance);
        });
    }

    toggleSpeech() {
        if (this.synthesis.speaking) {
            this.synthesis.cancel();
        }
    }

    async start() {
        try {
            this.hasStarted = true;
            this.updateStatus('Starting...');
            sounds.notification.play();
            await this.speak('Welcome to Voice Email System. Say help for available commands.');
            this.currentState = 'listening';
            this.updateStatus('Listening...');
            this.recognition.start();
        } catch (error) {
            console.error('Error starting voice system:', error);
            this.updateStatus('Error starting system. Click anywhere to try again.');
            this.hasStarted = false;
            sounds.error.play();
        }
    }

    async handleCommand(transcript) {
        this.transcriptDiv.textContent = `You said: ${transcript}`;
        this.updateStatus('Processing command...');

        // Check for shortcuts first
        if (this.shortcuts.has(transcript)) {
            await this.shortcuts.get(transcript)();
            return;
        }

        try {
            switch (this.currentState) {
                case 'listening':
                    await this.handleMainCommand(transcript);
                    break;
                case 'compose_to':
                    await this.handleContactInput(transcript);
                    break;
                case 'compose_subject':
                    this.emailData.subject = transcript;
                    this.currentState = 'compose_message';
                    await this.speak('What is your message?');
                    break;
                case 'compose_message':
                    this.emailData.text = transcript;
                    await this.sendEmail();
                    break;
                case 'search':
                    await this.searchEmails(transcript);
                    break;
                case 'folder_selection':
                    await this.changeFolder(transcript);
                    break;
                case 'contact_name':
                    this.contactName = transcript;
                    this.currentState = 'contact_email';
                    await this.speak('What is the email address?');
                    break;
                case 'contact_email':
                    await this.addContact(this.contactName, transcript);
                    break;
            }
        } catch (error) {
            console.error('Error handling command:', error);
            await this.speak('An error occurred. Please try again.');
            sounds.error.play();
            this.currentState = 'listening';
        }

        this.updateStatus('Listening...');
    }

    async handleMainCommand(command) {
        if (command.includes('speed up')) {
            this.speechRate = Math.min(2, this.speechRate + 0.25);
            await this.speak(`Speech rate is now ${this.speechRate}`);
        } else if (command.includes('slow down')) {
            this.speechRate = Math.max(0.5, this.speechRate - 0.25);
            await this.speak(`Speech rate is now ${this.speechRate}`);
        } else if (command === 'help') {
            await this.speakHelp();
        } else {
            switch (command) {
                case 'compose':
                    this.currentState = 'compose_to';
                    await this.speak('Who would you like to send the email to?');
                    break;
                case 'read':
                    await this.readEmails();
                    break;
                case 'search':
                    this.currentState = 'search';
                    await this.speak('What would you like to search for?');
                    break;
                case 'folders':
                    await this.listFolders();
                    break;
                case 'contacts':
                    await this.manageContacts();
                    break;
                case 'templates':
                    await this.listTemplates();
                    break;
                case 'exit':
                    await this.speak('Goodbye');
                    sounds.notification.play();
                    this.currentState = 'idle';
                    this.hasStarted = false;
                    this.updateStatus('Click anywhere to start');
                    break;
                default:
                    await this.speak('Unknown command. Say help for available commands.');
            }
        }
    }

    async handleContactInput(transcript) {
        const email = await contacts.get(transcript);
        if (email) {
            this.emailData.to = email;
            this.currentState = 'compose_subject';
            await this.speak('What is the subject?');
        } else {
            await this.speak('Contact not found. Please say the email address directly or add the contact first.');
            this.emailData.to = transcript;
            this.currentState = 'compose_subject';
            await this.speak('What is the subject?');
        }
    }

    async sendEmail() {
        try {
            this.updateStatus('Sending email...');
            const response = await fetch('/api/send-email', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(this.emailData)
            });
            
            const result = await response.json();
            await this.speak(result.message);
            sounds.success.play();
            this.currentState = 'listening';
            this.emailData = {};
        } catch (error) {
            console.error('Error sending email:', error);
            await this.speak('Error sending email');
            sounds.error.play();
            this.currentState = 'listening';
        }
    }

    async readEmails() {
        try {
            this.updateStatus('Fetching emails...');
            const response = await fetch(`/api/read-emails?folder=${this.currentFolder}`);
            const result = await response.json();
            
            if (result.success && result.emails.length > 0) {
                sounds.notification.play();
                await this.speak(`Found ${result.emails.length} emails in ${this.currentFolder}. Reading them now.`);
                
                for (const email of result.emails) {
                    await this.speak(`From: ${email.from}`);
                    await this.speak(`Subject: ${email.subject}`);
                    if (email.content) {
                        await this.speak(`Content: ${email.content.substring(0, 200)}`);
                    }
                    
                    await this.speak('Say next for next email or stop to stop reading');
                    this.updateStatus('Waiting for command (next/stop)...');
                    
                    const command = await new Promise(resolve => {
                        this.recognition.onresult = (event) => {
                            resolve(event.results[0][0].transcript.toLowerCase());
                        };
                        this.recognition.start();
                    });
                    
                    if (command.includes('stop')) break;
                }
            } else {
                await this.speak(`No emails found in ${this.currentFolder}`);
            }
        } catch (error) {
            console.error('Error reading emails:', error);
            await this.speak('Error reading emails. Please try again later.');
            sounds.error.play();
        }
        
        this.currentState = 'listening';
        this.updateStatus('Listening...');
    }

    async searchEmails(query) {
        try {
            const response = await fetch(`/api/search?query=${encodeURIComponent(query)}`);
            const result = await response.json();

            if (result.success && result.emails.length > 0) {
                sounds.notification.play();
                await this.speak(`Found ${result.emails.length} matching emails. Reading results.`);
                for (const email of result.emails) {
                    await this.speak(`From: ${email.from}`);
                    await this.speak(`Subject: ${email.subject}`);
                    await this.speak('Say next for next result or stop to stop reading');
                    
                    const command = await new Promise(resolve => {
                        this.recognition.onresult = (event) => {
                            resolve(event.results[0][0].transcript.toLowerCase());
                        };
                        this.recognition.start();
                    });
                    
                    if (command.includes('stop')) break;
                }
            } else {
                await this.speak('No matching emails found');
            }
        } catch (error) {
            console.error('Error searching emails:', error);
            await this.speak('Error searching emails');
            sounds.error.play();
        }
        
        this.currentState = 'listening';
    }

    async listFolders() {
        try {
            const response = await fetch('/api/folders');
            const result = await response.json();

            if (result.success && result.folders.length > 0) {
                await this.speak('Available folders are: ' + result.folders.join(', '));
                await this.speak('Say the folder name to switch to it');
                this.currentState = 'folder_selection';
            } else {
                await this.speak('No folders found');
                this.currentState = 'listening';
            }
        } catch (error) {
            console.error('Error fetching folders:', error);
            await this.speak('Error fetching folders');
            sounds.error.play();
            this.currentState = 'listening';
        }
    }

    async changeFolder(folderName) {
        this.currentFolder = folderName.toUpperCase();
        await this.speak(`Switched to folder ${folderName}`);
        sounds.success.play();
        this.currentState = 'listening';
    }

    async manageContacts() {
        await this.speak('Say add contact to add a new contact, or list contacts to hear your contacts');
        const command = await new Promise(resolve => {
            this.recognition.onresult = (event) => {
                resolve(event.results[0][0].transcript.toLowerCase());
            };
            this.recognition.start();
        });

        if (command === 'add contact') {
            this.currentState = 'contact_name';
            await this.speak('What is the contact name?');
        } else if (command === 'list contacts') {
            const contactList = await contacts.getAll();
            const contactNames = Object.keys(contactList);
            if (contactNames.length > 0) {
                await this.speak('Your contacts are: ' + contactNames.join(', '));
            } else {
                await this.speak('You have no contacts saved');
            }
            this.currentState = 'listening';
        }
    }

    async addContact(name, email) {
        await contacts.add(name, email);
        await this.speak(`Contact ${name} added successfully`);
        sounds.success.play();
        this.currentState = 'listening';
    }

    async listTemplates() {
        await this.speak('Available templates are: ' + Object.keys(emailTemplates).join(', '));
        await this.speak('Say the template name to use it');
        const command = await new Promise(resolve => {
            this.recognition.onresult = (event) => {
                resolve(event.results[0][0].transcript.toLowerCase());
            };
            this.recognition.start();
        });

        await this.useTemplate(command);
    }

    async useTemplate(templateName) {
        const template = emailTemplates[templateName];
        if (template) {
            this.emailData.subject = template.subject;
            this.emailData.text = template.text;
            this.currentState = 'compose_to';
            sounds.notification.play();
            await this.speak('Template loaded. Who would you like to send this email to?');
        } else {
            await this.speak('Template not found');
            sounds.error.play();
            this.currentState = 'listening';
        }
    }
}

// Initialize the system when the page loads
window.addEventListener('load', () => {
    new VoiceEmailSystem();
});